<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "metrointernational";

// Correct order: host, username, password, dbname
$conn = new mysqli($host, $username, $password, $dbname);

if($conn->connect_error){
    die("Database Connection failed: " . $conn->connect_error);
} 
?>
