<?php include("header.php")  ?>

<body>
    <h1>home page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur sit omnis nemo. Obcaecati voluptate dolore ut suscipit earum, tempore ducimus sed veniam architecto asperiores nam ullam dolor quisquam cupiditate! Dolor quasi quibusdam natus praesentium nihil quisquam numquam laudantium ullam ex ducimus, tempora aspernatur porro explicabo adipisci dolores? Exercitationem, dolore illum cum, iusto tempora aliquid dolorum odit et eum, reprehenderit recusandae obcaecati asperiores distinctio corporis praesentium impedit nesciunt vel qui! Saepe, at velit alias, ad non veniam hic quaerat facilis nemo ipsa atque id impedit ratione quae perferendis fugit expedita. Nemo alias quam quod molestias consectetur, temporibus in voluptatibus corporis earum.</p>
</body>

</html>