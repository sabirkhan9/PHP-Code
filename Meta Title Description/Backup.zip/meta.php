<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-4 ">
        <div class="row">
            <h2 class="h4 text-center mb-3">Existing Titles and Descriptions</h2>
            <div class="bd-example">
                <table class="table table-bordered border-primary">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">URL</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Edit/Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php include("get_data.php"); ?>
                        <?php for ($i = 0; $i < count($rows); $i++) { ?>
                            <tr>
                                <td><?= $rows[$i]['id']; ?></td>
                                <td><?= $rows[$i]['slug']; ?></td>
                                 <td><?= $rows[$i]['meta_title']; ?></td>
                                  <td><?= $rows[$i]['meta_description']; ?></td>
                                <td><a href="edit.php?id=<?= $rows[$i]['id']; ?>" class="btn btn-success">Edit</a></td>
                            </tr>
                        <?php } ?>
                        
                    </tbody>

                </table>
            </div>
        </div>


        <div class="row mt-4 pt-4">
            <h2 class="h4 text-center mb-3">New Add Titles and Descriptions</h2>
            <div class="bd-example">
                <table class="table table-bordered border-primary">
                    <thead>
                        <tr>
                            <th scope="col">URL</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Add</th>
                        </tr>
                    </thead>
                    <form action="http://localhost/meta/insert.php" method="post">
                        <tbody>
                            <tr>
                                <td><input type="text" name="slug" id="slug" required class="form-control"> </td>
                                <td><input type="text" name="meta_title" id="meta_title" required class="form-control"> </td>
                                <td><input type="text" name="meta_description" id="meta_description" required class="form-control"> </td>
                                <td><button type="submit" name="add_meta" class="btn btn-success">Add</button></td>
                            </tr>
                        </tbody>
                    </form>

                </table>
            </div>
        </div>

    </div>
</body>

</html>