<?php include("header.php")  ?>
<body>
    <h2>About us</h2>
</body>
</html>